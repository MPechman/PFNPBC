$(document).ready(function() {

});

function goToSleep() {
    $('.person').addClass('sleeping');
    $('#sleeping-bags').slideDown();
    $('#night-sky').fadeIn();
  }